#include "header.c"
void delete_record1(struct st **ptr,int n)
{
	struct st *temp,*prev;
	temp=*ptr;
	while(1)
	{
		if(temp->roll==n)
		{
			if(temp==*ptr)
				temp=(*ptr)->next;
			else
				prev->next=temp->next;

			free(temp);
			temp=NULL;
			return;
		}
		else
		{
			prev=temp;
			temp=temp->next;
		}
		printf("INVALID DATA\n");
	}
}

void delete_record2(struct st **ptr,char na[])
{
	struct st *temp,*prev;
	temp=*ptr;
	while(1)
	{
		if((strcmp(temp->name,na))==0)
		{
			if(temp==*ptr)
				temp=(*ptr)->next;
			else
				prev->next=temp->next;

			free(temp);
			temp=NULL;
			return;
		}
		else
		{
			prev=temp;
			temp=temp->next;
		}
	}
}
void delete_record3(struct st**ptr,float ma)
{
	struct st *temp,*prev;
	temp=*ptr;
	while(1)
	{
		if(temp->mark==ma)
		{
			if(temp==*ptr)
				temp=(*ptr)->next;
			else
				prev->next=temp->next;

			free(temp);
			temp=NULL;
			return;
		}
		else
		{
			prev=temp;
			temp=temp->next;
		}
	}
}
