#include<stdio.h>
int main()
{
	int i,j,n=5;
	for(i=0;i<=n;i++)
	{
		for(j=0;j<=n;j++)
		{
			if((i==0)||(i==n))
			{
				printf("* ");
			}
			else if((i==(j+i))||(n<=j))
			{
				printf("* ");
			}
		/*	else if((i==n)&&(i<=n))
			{
				printf("* ");
			}*/
			else
				printf("  ");
		}
		printf("\n");
	}
}

