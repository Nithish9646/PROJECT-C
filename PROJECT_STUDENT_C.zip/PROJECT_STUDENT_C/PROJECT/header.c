#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct st 
{
	int roll;
	char name[20];
	float mark;
	struct st * next;
};

void add_begin(struct st **);
void print(struct st *);
void delete_record1(struct st **,int);
void delete_record2(struct st **,char[20]);
void delete_record3(struct st **,float);
void delete_all_record(struct st *);
void reverse_detail(struct st **);
int count(struct st *);
void save(struct st *);
void sorting(struct st **);
void modify_record(struct st **);
