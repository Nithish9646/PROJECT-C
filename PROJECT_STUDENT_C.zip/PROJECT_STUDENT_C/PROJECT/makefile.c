outfile: header.o add-begin.o delete-all-record.o delete-record.o modify.o student-record.o reverse-the-list.o save.o sorting.o show.o count.o
       cc header.c cc add-begin.c cc delete-all-record.c cc delete-record.c cc modify.c cc student-record.c cc reverse-the-list.c cc save.c cc sorting.c cc show.c cc count.c -o student

header.o:header.c
         cc -c header.c
add-begin.o:add-begin.c
	cc -c add-begin.c
delete-all-record.o:delete-all-record.c
	cc -c delete-all-record.c
delete-record.o:delete-record.c
	cc -c delete-record.c
modify.o:modify.c
	cc -c modify.c
student-record.o:student-record.c
	cc -c student-record.c
reverse-the-list.o:reverse-the-list.c
	cc -c reverse-the-list.c
save.o:save.c
	cc -c save.c
sorting.o:sorting.c
	cc -c sorting.c
show.o:show.c
	cc -c show.c
count.o:count.c
	cc -c count.c



